package tatetiDiego;
import java.util.Scanner;
public class ProyectoTateti {

	public static void main(String[] args) {
		String[] tablero = {"_","_","_" ,"_","_","_","_","_","_"};
	   int numerojugadas;
	   numerojugadas = 0;
		boolean alguienGano = false;
		boolean hayEmpate = false;
		
	   do {
		   MostrarTablero(tablero);
		   String ficha = numerojugadas%2==0? "X":"O";
		   Jugada(ficha, tablero);
		   alguienGano = QuienGano(tablero);
		   hayEmpate = Empate(tablero);
		   if(hayEmpate && !alguienGano)System.out.println("Empate.");
		   if(alguienGano)System.out.println("Jugador "+ ficha +" ganó");
		   numerojugadas++;
	   }while(!alguienGano || !hayEmpate); 
	   
	}

	
	
	public static void MostrarTablero(String[] tablero ) {
	// Muestra el Tablero
		System.out.println(tablero[0] + " | " + tablero[1] + " | " + tablero[2] + " | ");
	System.out.println(tablero[3] + " | " + tablero[4] + " | " + tablero[5] + " | ");	
	System.out.println(tablero[6] + " | " + tablero[7] + " | " + tablero[8] + " | ");
}

static void Jugada(String ficha , String [] tablero) {
	//Pedir una posicion en el tablero, verificar si la posicion es menor a 8 y no esta ocupada por X o O.
	// Si esta ocupada por X o O, dar error y reintento.
	Scanner sc= new Scanner(System.in);
	System.out.println("Elija un espacio en el tablero, jugador " + ficha);
		int posicion = sc.nextInt();
		while(posicion > 8 || !tablero[posicion].equals("_")) {
	    	System.out.println("Jugada Invalida, intentelo de nuevo");
	    	posicion = sc.nextInt();
	    }
			tablero[posicion] = ficha;	
		

  

}
static boolean QuienGano(String[] tablero) {
	//Comprueba si alguien ha ganado. 
	if(tablero[0].equals(tablero[1]) && tablero[0].equals(tablero[2]) && !tablero[0].equals("_")) {
		 return true;
	 }else if(tablero[3].equals(tablero[4]) && tablero[3].equals(tablero[5]) && !tablero[3].equals("_")){
		 return true;
	 }else if(tablero[6].equals(tablero[7]) && tablero[6].equals(tablero[8]) && !tablero[6].equals("_")){
       return true;
}else if(tablero[0].equals(tablero[3]) && tablero[0].equals(tablero[6]) && !tablero[0].equals("_")){
return true;
}else if(tablero[1].equals(tablero[4]) && tablero[1].equals(tablero[7]) && !tablero[1].equals("_")){
return true;
	}else if(tablero[2].equals(tablero[5]) && tablero[2].equals(tablero[8]) && !tablero[2].equals("_")){
	return true;
	}else if(tablero[0].equals(tablero[4]) && tablero[0].equals(tablero[8]) && !tablero[0].equals("_")){
return true;
} else if(tablero[2].equals(tablero[4]) && tablero[2].equals(tablero[6]) && !tablero[2].equals("_")){
return true;	 
}
return false;
}
static boolean Empate(String[] tablero) { 
	// Comprueba si alguien ha empatado          
	int iter=0;
	          while(iter<9) {
	        	//Preguntamos si cada espacio del tablero contiene un espacio en blanco, en caso de verdadero, sigue el juego.
	        	 
	        	  if(tablero[iter].equals("_")) {
	        		  return false;
	        		
	        	  }
	        	  iter++;
	          }
	          return true;
}
	
}






 
 
 
 
 
